import pandas as pd
import matplotlib.pyplot as plt

# reading the dataset
df = pd.read_csv('D:\Desktop\SMA\Practicals\SMA Pycharm Pracs\Hashtag Analysis\ghana_nigeria_takedown_tweets.csv')
print(df)

# Grouping the data and counting frequency of each hashtag
grouped = df.groupby('tweet_client_name')['hashtags'].apply(lambda x: pd.Series([tag for tags in x.dropna() for tag in tags.split()]).value_counts())
print("\n\n")
print(grouped)

print()
for group in grouped.index.levels[0]:
    print(f'Top 5 hashtags for {group}: \n')
    print(grouped[group].head(5))
    print()

print()
client_name = 'Twitter for Android'
fig,ax = plt.subplots(figsize = (10,15))
top_hashtags = grouped[client_name].head(5)
ax.bar(top_hashtags.index, top_hashtags.values)
ax.set_title(f'Top 5 hashtags for {client_name}')
ax.set_xlabel('Hashtags')
ax.set_ylabel('Frequency')

plt.tight_layout()
plt.show()

"""Different dataset"""

import pandas as pd
import ast
import warnings
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')

dataset = pd.read_csv('tweets.csv')
dataset['Country'] = 'None'
dataset['Hashtags'] = ''

for i,row in dataset.iterrows():
    loc_data = ast.literal_eval(row['additional_data'])
    hashtags = [token for token in row.tweet.split() if token.startswith('#')]
    dataset['Hashtags'][i] = hashtags

    if loc_data['place']:
        dataset['Country'][i] = loc_data['place']['country']

dataset = dataset[dataset['Country'] != 'None']
dataset = dataset[['Country','Hashtags']]
dataset = dataset.explode('Hashtags')

for country in dataset['Country'].unique():
    dataset_country = dataset[dataset['Country'] == country]
    dataset_country['Hashtags'].value_counts().plot(kind = 'barh')
    plt.xlabel('Hashtag Count')
    plt.ylabel('Hashtags')
    plt.title(f'Hashtag Popularity in {country}')
    plt.show()


"""Different code"""

'''
To determine which hashtags are most popular among different user groups, we can use the following approach:
- Read in the CSV file containing the social media data and filter it to include only the columns we need (e.g. user ID, user group, and hashtags).
- Split the hashtags into individual words and count their frequency for each user group.
- Plot the top N most frequent hashtags for each user group in a bar chart.
'''

import pandas as pd
import matplotlib.pyplot as plt

# Read in the CSV file
df = pd.read_csv('hashtag_analysis.csv')

# Group the data by hashtags and user groups, and count the occurrences
hashtags_by_group = df.groupby(
    ['user_group', 'hashtags']).size().reset_index(name='count')

# Plot a horizontal bar chart for each user group
for group in df['user_group'].unique():
    group_data = hashtags_by_group[hashtags_by_group['user_group'] == group].sort_values('count', ascending=False).head(10)
    ax = group_data.plot(kind='barh', x='hashtags', y='count',
                         legend=False, title=f'Top Hashtags for {group}')
    ax.set_xlabel('Frequency')
    plt.tight_layout()
    plt.show()